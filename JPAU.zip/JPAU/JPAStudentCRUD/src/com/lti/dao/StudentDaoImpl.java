package com.lti.dao;

import javax.persistence.EntityManager;
import com.lti.pojo.Student;
import com.lti.utils.JpaUtils;

public class StudentDaoImpl implements StudentDao {
	private EntityManager entityManager = null;
	Student student2 = null;
	Student student = null;
	
	public StudentDaoImpl() {
		entityManager = JpaUtils.getEntityManager();
	}

	@Override
	public int createStudent(Student student) {
		
		
		
		entityManager.persist(student);
		
		return 1;
		
	}

	@Override
	public Student readStudent(int rollNumber) {
		student2=entityManager.find(Student.class, rollNumber);
		//System.out.println(student2);
		return student2;
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void rollbackTransaction() {
		entityManager.getTransaction().rollback();
		
		
	}

//	@Override
//	public void commitTransaction() {
//		
//		
//	}
//
//	@Override
//	public void rollbackTransaction() {
//	
//		
//	}
//
//	@Override
//	public void beginTransaction() {
//		
//		 entityManager.getTransaction.begin();
//	}

	
}
