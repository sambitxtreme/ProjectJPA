package com.lti.service;

import com.lti.pojo.Student;

public interface StudentService {
	public boolean addStudent(Student student);
	public Student findStudentByRollNumber(int rollNumber);
	
	
	
}
