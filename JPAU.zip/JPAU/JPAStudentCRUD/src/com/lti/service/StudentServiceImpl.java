package com.lti.service;

import com.lti.dao.StudentDao;
import com.lti.dao.StudentDaoImpl;
import com.lti.pojo.Student;

public class StudentServiceImpl implements StudentService {
	private StudentDao dao;
	public StudentServiceImpl(){
		dao=new StudentDaoImpl();
	}
	@Override
	public boolean addStudent(Student student) {
		 	int result	=dao.createStudent(student);
		 	if(result==1)
		return true;
		 	else
		 		return false;
	}

	@Override
	public Student findStudentByRollNumber(int rollNumber) {
		
	return dao.readStudent(rollNumber);
	}

}
